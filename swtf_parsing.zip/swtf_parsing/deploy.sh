docker-compose down
docker image  prune  -a -f
docker-compose build
docker-compose up -d