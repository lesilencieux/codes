import re
import psycopg2
from decouple import config

# Charger les variables d'environnement depuis le fichier .env
DB_NAME = config('DB_NAME')
DB_USER = config('DB_USER')
DB_PASSWORD = config('DB_PASSWORD')
DB_HOST = config('DB_HOST')
DB_PORT = config('DB_PORT')

# Fonction pour établir la connexion à la base de données
def create_db_connection():
    return psycopg2.connect(
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT
    )

conn = create_db_connection()

cursor = conn.cursor()

# Fonction pour extraire les informations du message SWIFT
def extract_swift_data(swift_message):
    match = re.search(r':20:\s*(\S+)', swift_message)
    transaction_reference = match.group(1) if match else None

    match = re.search(r':32A:\s*(\S+)', swift_message)
    amount_and_currency = match.group(1) if match else None

    match = re.search(r':50K:\s*\/(.+?)\n', swift_message, re.DOTALL)
    ordering_customer = match.group(1) if match else None

    match = re.search(r':59:(.+?)\n', swift_message, re.DOTALL)
    beneficiary_customer = match.group(1) if match else None

    match = re.search(r':70:(.+?)\n', swift_message, re.DOTALL)
    remittance_information = match.group(1) if match else None

    match = re.search(r'{5:{CHK:(.+?)}}', swift_message)
    checksum = match.group(1) if match else None

    return transaction_reference, amount_and_currency, ordering_customer, beneficiary_customer, remittance_information, checksum

# Fonction pour insérer les données dans la base de données
def insert_into_database(transaction_reference, amount_and_currency, ordering_customer, beneficiary_customer, remittance_information, checksum):
    if transaction_reference and amount_and_currency:
        query = """
        INSERT INTO transactions (
            transaction_reference,
            amount_and_currency,
            ordering_customer,
            beneficiary_customer,
            remittance_information,
            checksum
        ) VALUES (%s, %s, %s, %s, %s, %s)
        """
        values = (
            transaction_reference,
            amount_and_currency,
            ordering_customer,
            beneficiary_customer,
            remittance_information,
            checksum
        )
        cursor.execute(query, values)
        conn.commit()
# Chemin vers le fichier texte
path_file = 'datas.txt'

# Fonction pour lire les données à partir du fichier texte
def get_datas_from_file(path_file):
    with open(path_file, 'r') as file:
        lines = file.readlines()
    return lines

# Votre message SWIFT
swift_messages = get_datas_from_file(path_file)

# Divisez les messages SWIFT
swift_messages = swift_messages.split("${")

# Boucle à travers les messages
for swift_message in swift_messages:
    transaction_reference, amount_and_currency, ordering_customer, beneficiary_customer, remittance_information, checksum = extract_swift_data(swift_message)
    insert_into_database(transaction_reference, amount_and_currency, ordering_customer, beneficiary_customer, remittance_information, checksum)

# Fermez la connexion à la base de données
cursor.close()
conn.close()