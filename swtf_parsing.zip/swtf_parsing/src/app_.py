import psycopg2
import json
from decouple import config


# Charger les variables d'environnement depuis le fichier .env
DB_NAME = config('DB_NAME')
DB_USER = config('DB_USER')
DB_PASSWORD = config('DB_PASSWORD')
DB_HOST = config('DB_HOST')
DB_PORT = config('DB_PORT')

# Paramètres de connexion à la base de données PostgreSQL
db_params = {
    'dbname': DB_NAME,
    'user': DB_USER,
    'password': DB_PASSWORD,
    'host': DB_HOST,  # Mettez l'adresse de votre serveur PostgreSQL
    'port': DB_PORT        # Port par défaut de PostgreSQL
}

# Chemin vers le fichier texte
path_file = 'datas.txt'

# Fonction pour lire les données à partir du fichier texte
def get_datas_from_file(path_file):
    with open(path_file, 'r') as file:
        lines = file.readlines()
    return lines

# Fonction pour enregistrer les données dans la base de données PostgreSQL
def save_data_into_db(data, conn):
    cursor = conn.cursor()
    for line in data:
        # Charger la ligne en tant qu'objet JSON
        try:
            json_data = json.loads(line.strip())
        except json.JSONDecodeError as e:
            print(f"Erreur lors de la conversion JSON : {e}")
            continue
        
        # Modifiez cette requête en fonction de la structure de vos données et de votre base de données
        query = "INSERT INTO nom_de_votre_table (sender, receiver, date, amount) VALUES (%s, %s, %s, %s);"
        values = (json_data['sender'], json_data['receiver'], json_data['date'], json_data['amount'])
        
        cursor.execute(query, values)
    
    conn.commit()
    cursor.close()

# Connexion à la base de données
try:
    connection = psycopg2.connect(**db_params)
    print("Connexion à la base de données réussie.")
    
    # Lecture des données à partir du fichier
    data = get_datas_from_file(path_file)
    
    # Enregistrement des données dans la base de données PostgreSQL
    save_data_into_db(data, connection)

except (Exception, psycopg2.Error) as error:
    print("Erreur lors de la connexion à la base de données ou de l'enregistrement des données:", error)

finally:
    # Fermeture de la connexion à la base de données
    if connection:
        connection.close()
        print("Connexion à la base de données fermée.")
